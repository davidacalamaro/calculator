//
//  ViewController.swift
//  calculator
//
//  Created by david on 10/6/21.
//

import UIKit

class ViewController: UIViewController
{

    
    @IBOutlet weak var output: UILabel! //THIS IS THE LABEL
    var calc = 0.0
    var sec = 0.0
    var op = false
    var p = false
    var m = false
    var t = false
    var d = false
    @IBOutlet weak var toad: UIImageView!
    var quack = false
    // wahh wahh i dont wanna make le booleans
    
    
    
    
    
    
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        toad.image = UIImage(named: "toad")
        output.text = "\(calc)"
        toad.isHidden = true
    }

    
    
    @IBAction func seven(_ sender: UITapGestureRecognizer)
    {
        if op == false
        {
        calc = (calc*10) + 7
        }
        
        else
        {
            sec = (sec*10) + 7
        }
     ///////////////////////////////////////////////////// copy here, paste for each number
    
        if p == true //plus
        {
            output.text = "\(calc) + \(sec)"
           // calc = calc+sec
            print(calc)
        }
        
    
       else if m == true //minus
        {
            output.text = "\(calc) - \(sec)"
         //   calc = calc-sec
       }
        
    
        else if t == true //times
        {
            output.text = "\(calc) x \(sec)"
           // calc = calc*sec
            print(calc)
        }
    
       else if d == true //divide
        {
            output.text = "\(calc) ÷ \(sec)"
           //calc = calc/sec
        }
       
        else
        {
            output.text = "\(calc)"
        }
    ////////////////////////////////////////////////////////////////////////////////////////////
    
    
    
    }
    
    
    
    @IBAction func eight(_ sender: UITapGestureRecognizer)
    {
        if op == false
        {
        calc = (calc*10) + 8
        }
        
        else
        {
            sec = (sec*10) + 8
        }
        
            if p == true //plus
            {
                output.text = "\(calc) + \(sec)"
               // calc = calc+sec
                print(calc)
            }
            
        
           else if m == true //minus
            {
                output.text = "\(calc) - \(sec)"
              //  calc = calc-sec
           }
            
        
            else if t == true //times
            {
                output.text = "\(calc) x \(sec)"
               // calc = calc*sec
                
            }
        
           else if d == true //divide
            {
                output.text = "\(calc) ÷ \(sec)"
              // calc = calc/sec
            }
        
            else
            {
                output.text = "\(calc)"
            }
        
    }
    
    
    
    @IBAction func nine(_ sender: UITapGestureRecognizer)
    {
        if op == false
        {
        calc = (calc*10) + 9
        }
        
        else
        {
            sec = (sec*10) + 9
        }
        
            if p == true //plus
            {
                output.text = "\(calc) + \(sec)"
              //  calc = calc+sec
                print(calc)
            }
            
        
           else if m == true //minus
            {
                output.text = "\(calc) - \(sec)"
              //  calc = calc-sec
           }
            
        
            else if t == true //times
            {
                output.text = "\(calc) x \(sec)"
             //   calc = calc*sec
                
            }
        
           else if d == true //divide
            {
                output.text = "\(calc) ÷ \(sec)"
              // calc = calc/sec
            }
        
            else
            {
                output.text = "\(calc)"
            }
        
    }
    
    
    
    @IBAction func four(_ sender: UITapGestureRecognizer)
    {
        if op == false
        {
        calc = (calc*10) + 4
        }
        
        else
        {
            sec = (sec*10) + 4
        }
        
            if p == true //plus
            {
                output.text = "\(calc) + \(sec)"
              //  calc = calc+sec
                print(calc)
            }
            
        
           else if m == true //minus
            {
                output.text = "\(calc) - \(sec)"
             //   calc = calc-sec
           }
            
        
            else if t == true //times
            {
                output.text = "\(calc) x \(sec)"
              //  calc = calc*sec
                
            }
        
           else if d == true //divide
            {
                output.text = "\(calc) ÷ \(sec)"
              // calc = calc/sec
            }
        
            else
            {
                output.text = "\(calc)"
            }
        
    }
    
    
    
    @IBAction func five(_ sender: UITapGestureRecognizer)
    {
        if op == false
        {
        calc = (calc*10) + 5
        }
        
        else
        {
            sec = (sec*10) + 5
        }
        
            if p == true //plus
            {
                output.text = "\(calc) + \(sec)"
               // calc = calc+sec
                print(calc)
            }
            
        
           else if m == true //minus
            {
                output.text = "\(calc) - \(sec)"
              //  calc = calc-sec
           }
            
        
            else if t == true //times
            {
                output.text = "\(calc) x \(sec)"
                //calc = calc*sec
                
            }
        
           else if d == true //divide
            {
                output.text = "\(calc) ÷ \(sec)"
              // calc = calc/sec
            }
        
            else
            {
                output.text = "\(calc)"
            }
        
    }
    
    
    @IBAction func six(_ sender: UITapGestureRecognizer)
    {
        if op == false
        {
        calc = (calc*10) + 6
        }
        
        else
        {
            sec = (sec*10) + 6
        }
        
            if p == true //plus
            {
                output.text = "\(calc) + \(sec)"
              //  calc = calc+sec
                print(calc)
            }
            
        
           else if m == true //minus
            {
                output.text = "\(calc) - \(sec)"
               // calc = calc-sec
           }
            
        
            else if t == true //times
            {
                output.text = "\(calc) x \(sec)"
               // calc = calc*sec
                
            }
        
           else if d == true //divide
            {
                output.text = "\(calc) ÷ \(sec)"
             //  calc = calc/sec
            }
        
            else
            {
                output.text = "\(calc)"
            }
        
    }
    
    
    
    
    @IBAction func one(_ sender: UITapGestureRecognizer)
    {
        if op == false
        {
        calc = (calc*10) + 1
        }
        
        else
        {
            sec = (sec*10) + 1
        }
        
            if p == true //plus
            {
                output.text = "\(calc) + \(sec)"
                //calc = calc+sec
                print(calc)
            }
            
        
           else if m == true //minus
            {
                output.text = "\(calc) - \(sec)"
                //calc = calc-sec
           }
            
        
            else if t == true //times
            {
                output.text = "\(calc) x \(sec)"
               // calc = calc*sec
                
            }
        
           else if d == true //divide
            {
                output.text = "\(calc) ÷ \(sec)"
              // calc = calc/sec
            }
        
            else
            {
                output.text = "\(calc)"
            }
        
    }
    
    
    
    
    @IBAction func two(_ sender: UITapGestureRecognizer)
    {
        if op == false
        {
        calc = (calc*10) + 2
        }
        
        else
        {
            sec = (sec*10) + 2
        }
        
            if p == true //plus
            {
                output.text = "\(calc) + \(sec)"
                //calc = calc+sec
                print(calc)
            }
            
        
           else if m == true //minus
            {
                output.text = "\(calc) - \(sec)"
               // calc = calc-sec
           }
            
        
            else if t == true //times
            {
                output.text = "\(calc) x \(sec)"
               // calc = calc*sec
                
            }
        
           else if d == true //divide
            {
                output.text = "\(calc) ÷ \(sec)"
               //calc = calc/sec
            }
        
            else
            {
                output.text = "\(calc)"
            }
        
    }
    
    
    @IBAction func three(_ sender: UITapGestureRecognizer)
    {
        if op == false
        {
        calc = (calc*10) + 3
        }
        
        else
        {
            sec = (sec*10) + 3
        }
        
            if p == true //plus
            {
                output.text = "\(calc) + \(sec)"
               // calc = calc+sec
                print(calc)
            }
            
        
           else if m == true //minus
            {
                output.text = "\(calc) - \(sec)"
               // calc = calc-sec
           }
            
        
            else if t == true //times
            {
                output.text = "\(calc) x \(sec)"
               // calc = calc*sec
                
            }
        
           else if d == true //divide
            {
                output.text = "\(calc) ÷ \(sec)"
              // calc = calc/sec
            }
        
            else
            {
                output.text = "\(calc)"
            }
        
    }
    
    
    @IBAction func zero(_ sender: UITapGestureRecognizer)
    {
        if op == false
        {
        calc = (calc*10) + 0
        }
        
        else
        {
            sec = (sec*10) + 0
        }
        
            if p == true //plus
            {
                output.text = "\(calc) + \(sec)"
                //calc = calc+sec
                print(calc)
            }
            
        
           else if m == true //minus
            {
                output.text = "\(calc) - \(sec)"
                //calc = calc-sec
           }
            
        
            else if t == true //times
            {
                output.text = "\(calc) x \(sec)"
               // calc = calc*sec
                
            }
        
           else if d == true //divide
            {
                output.text = "\(calc) ÷ \(sec)"
               //calc = calc/sec
            }
        
            else
            {
                output.text = "\(calc)"
            }
        
    }
   
    
    /////////////////////////////// operators
    
    
    
    @IBAction func clear(_ sender: UITapGestureRecognizer)
    {
        output.text = "\(0.0)"
        calc = 0.0
        sec = 0.0
        op = false
        p = false
        m = false
        t = false
        d = false
        toad.isHidden = true
    }
    
    
    @IBAction func plus(_ sender: UITapGestureRecognizer)
    {
        p = true
        op = true
        
        if sec != 0.0
        {
        output.text = "\(calc) + \(sec)"
           // calc = calc+sec
        }
   
        else
        {
            output.text = "\(calc) +"
        }
        print("\(calc)")
        
    }
    
    @IBAction func minus(_ sender: UITapGestureRecognizer)
    {
        m = true
        op = true
       // calc = calc-sec
        if sec != 0.0
        {
        output.text = "\(calc) - \(sec)"
        }
   
        else
        {
            output.text = "\(calc) -"
        }
    }
    
    
    
    @IBAction func times(_ sender: UITapGestureRecognizer)
    {
        t = true
        op = true
       // calc = calc*sec
        if sec != 0.0
        {
        output.text = "\(calc) x \(sec)"
        }
   
        else
        {
            output.text = "\(calc) x"
        }
    print("times 1 \(calc)    sec \(sec)")
    
    
    
    }
    
    /////////////////////////////////////////////////////////////////
   
    @IBAction func equals(_ sender: UITapGestureRecognizer)
    {
        print("\(calc)  \(sec)")
      
        // do the if for each operator
        if p == true
        {
            calc = calc + sec
        }
        
        else if m == true
        {
            calc = calc-sec
        }
        
        else if t == true
        {
            calc = calc*sec
        }
        
        else if d == true
        {
            calc = calc / sec
        }
        
        output.text = "\(calc)"
        sec = 0.0
        op = false
        p = false
        m = false
        t = false
        d = false
       
        if calc == 64.0
        {
            toad.image = UIImage(named: "toad")
        }
    
        else if Int(calc)%2 == 0
        {
            toad.image = UIImage(named: "lol")
            
        }
    
        else if Int(calc)%2 != 0
        {
            toad.image = UIImage(named: "pear")
            
        }
        toad.isHidden = false
    
    
    
    }
   ///////////////////////////////////////////////////////////////////////
    
    @IBAction func divide(_ sender: UITapGestureRecognizer)
    {
        op = true
        d = true
       // calc = (calc)/sec
        if sec != 0.0
        {
        output.text = "\(calc) ÷ \(sec)"
        }
   
        else
        {
            output.text = "\(calc) ÷"
        }
    }
     
    //quack
    
    //end of operators
    
    

}

